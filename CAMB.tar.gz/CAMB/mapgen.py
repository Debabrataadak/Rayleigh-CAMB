import numpy as np
import matplotlib.pyplot as plt
import healpy as hp


data_sep=np.loadtxt("outputs/planck_diff_commonalities_mar2013_total_seperate_lensedCls.dat_1_1")
nside=128
cij=np.zeros((5,5,3*nside-1))
for i in range (2,7):
    for j in range(2,7):
        cl_f1_f2=np.zeros(np.shape(data_sep))
        cl_f1_f2[:,0]=data_sep[:,0]
        data_sep_1_f1=np.loadtxt("outputs/planck_diff_commonalities_mar2013_total_seperate_lensedCls.dat_1_%d"%(i))
        data_sep_1_f2=np.loadtxt("outputs/planck_diff_commonalities_mar2013_total_seperate_lensedCls.dat_1_%d"%(j))
        data_sep_f1_f2=np.loadtxt("outputs/planck_diff_commonalities_mar2013_total_seperate_lensedCls.dat_%d_%d"%(i,j))
        cl_f1_f2[:,1:]=  data_sep_f1_f2[:,1:] #data_sep[:,1:] + data_sep_1_f1[:,1:] + data_sep_1_f2[:,1:] + data_sep_f1_f2[:,1:]
        #plt.plot(data_sep[:,0],abs(cl_f1_f2[:,1]),label="%d_%d"%(i,j))
        print("%d_%d"%(i,j))
        cij[i-2][j-2][2:]=cl_f1_f2[:,1][:3*nside-3]*2*np.pi/(cl_f1_f2[:,0][:3*nside-3]*(cl_f1_f2[:,0][:3*nside-3]+1))
        #np.savetxt("outputs/planck_diff_commonalities_mar2013_total_lensedCls.dat_%d_%d"%(i,j),cl_f1_f2)

#plt.loglog()
#plt.legend() 



def correl_map_set(ns,nmocks,C_ij,RAM=8):
    #
    #[CHM, April 2024]
    #
    #This routine renders nmocks sets of range(C_ij) Gaussian maps on the sphere that are correlated as dictated
    #by the covariance matrix C_ij. This covariance matrix is assumed to have dimensions (Nr,Nr,lmax+1)
    #
    #The input values of ns, lmax are assume to be "sensible"
    #ns: nside parameter for HEALPix maps
    #nmocks: number of mock sets to be generated
    #
    #RAM is an optional input variable giving the RAM memory available (in GB)
    #
    import healpy as hp
    import numpy as np
    #
    Nr=np.size(C_ij,axis=0) ; lmax=np.size(C_ij,axis=2)-1 ; Amatrix=np.zeros( (Nr,Nr,lmax+1) )
    #
    #Computing projection matrix
    #
    for iNr in range(1,Nr):
        Amatrix[iNr,0,2:lmax+1]=C_ij[iNr,0,2:lmax+1]/np.sqrt(C_ij[0,0,2:lmax+1])
    #
    Amatrix[0,0,2:lmax+1]=np.sqrt(C_ij[0,0,2:lmax+1])
    for iNr in range(1,Nr):
        for iNr2 in range(1,iNr):
            Amatrix[iNr,iNr2,2:lmax+1]=C_ij[iNr,iNr2,2:lmax+1].copy()
            for iNr3 in range(iNr2-1,-1,-1):
                Amatrix[iNr,iNr2,2:lmax+1]-=Amatrix[iNr,iNr3,2:lmax+1]*Amatrix[iNr2,iNr3,2:lmax+1]
            Amatrix[iNr,iNr2,2:lmax+1]/=Amatrix[iNr2,iNr2,2:lmax+1]
        Amatrix[iNr,iNr,2:lmax+1]=C_ij[iNr,iNr,2:lmax+1].copy()
        for iNr2 in range(iNr-1,-1,-1):
            Amatrix[iNr,iNr,2:lmax+1]-=Amatrix[iNr,iNr2,2:lmax+1]**2
            #print('tsts=',iNr,iNr2,Amatrix[iNr,iNr,2:lmax+1])
        Amatrix[iNr,iNr,2:lmax+1]=np.sqrt(np.abs(Amatrix[iNr,iNr,2:lmax+1]))
    #
    #print('>> lmax,A_matrix :', lmax,Amatrix)
    #
    if ( (lmax+1)*(lmax+1)*nmocks*Nr*8>RAM/2*1e9): # assuming real*8 precision
        print('>> RAM required at matrix allocation may surpass adopted local RAM value')
    #
    #
    psi=np.random.normal( size=(Nr,nmocks,2,lmax+1,lmax+1) ) # Gaussian harmonic coefficients, both real and imaginary parts
    alm0=(psi[:,:,0,:,:]+1.j*psi[:,:,1,:,:]) / np.sqrt(2.) # complex a_lm array
    psi=np.ones(1) # deallocating big psi array
    #
    for il in range(lmax+1):
        alm0[:,:,il,:il+1]=np.tensordot(Amatrix[:,:,il],alm0[:,:,il,:il+1],axes=([1],[0])) # results in (Nr,nmocks,il+1) array
        alm0[:,:,il,0]=np.real(alm0[:,:,il,0]*np.sqrt(2)) + 0.j # we renormalize the m=0 harmonics
        #print(' / show how many times alm0 is not finite * il: ',il,np.sum(np.isfinite(alm0[:,:,il,:])==0)) 
    #
    print('>> Rotating into 1-D alm-s',alm0.shape,alm0.dtype)
    nlm=hp.Alm.getsize(lmax) ; alm11d=np.zeros( (Nr,nmocks,nlm),dtype=complex)
    for il in range(lmax+1):
        inn=hp.Alm.getidx(lmax,il,np.arange(il+1,dtype=int))
        alm11d[:,:,inn]=alm0[:,:,il,:il+1]
    alm0=np.zeros(1) # deallocating alm1
    #
    map_ar=np.zeros( (nmocks,Nr,12*ns*ns) )
    for isim in range(nmocks):
        for iNr in range(Nr):
            map_ar[isim,iNr,:]=hp.alm2map(alm11d[iNr,isim,:],ns,lmax=lmax)
    #
    return map_ar

nmaps=10
map_ar=correl_map_set(nside,nmaps,cij)
#hp.mollview(map_ar[0,1,:])
cl_map=0
cl_map_cross=0
for ii in range(nmaps):
    cl_map=cl_map + hp.anafast(map_ar[ii,2,:])
    cl_map_cross=cl_map_cross + hp.anafast(map_ar[ii,2,:],map_ar[ii,3,:])
cl_map=cl_map/nmaps
cl_map_cross=cl_map_cross/nmaps
ll=np.arange(len(cl_map)-1)
plt.loglog(ll[2:],ll[2:]*(ll[2:]+1)*cij[2,2,2:len(ll)])
plt.loglog(ll[2:],ll[2:]*(ll[2:]+1)*cij[2,3,2:len(ll)])
plt.loglog(ll[2:],ll[2:]*(ll[2:]+1)*cl_map[2:len(ll)])
plt.loglog(ll[2:],ll[2:]*(ll[2:]+1)*cl_map_cross[2:len(ll)])
plt.show()

       
